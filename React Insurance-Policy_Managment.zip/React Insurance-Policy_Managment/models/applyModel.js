const mongoose = require("mongoose");

const applicationSchema = new mongoose.Schema(
  {
    userId: {
      type: String,
      required: true,
    },
    policyId: {
      type: String,
      required: true,
    },
    policyInfo: {
      type: String,
      required: true,
    },
    userInfo: {
      type: String,
      required: true,
    },
    status: {
      type: String,
      required: true,
      default: "pending",
    },
})

const applicationModel = mongoose.model("applications", applicationSchema);

module.exports = applicationModel;