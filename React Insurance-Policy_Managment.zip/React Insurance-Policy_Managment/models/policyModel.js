const mongoose=require ('mongoose')

const policySchema=new mongoose.Schema({
    userId:{
        type:String,
    },
    policyName:{
        type:String,
        required:[true,'policy name is required']
    },
    description:{
        type:String,
        required:[true,'description is required']
    },
    helpline:{
        type:String,
        required:[true,'helpline no is required']
    },
    email:{
        type:String,
        required:[true,'email is required']
    },
    coverage:{
        type:String,
        required:[true,'coverage is required']
    },
    feesPerMonth:{
        type:Number,
        required:[true,'fee is required']
    },
    status:{
        type:String,
        default:'pending'
    }
},{timestamps:true})

const policyModel=mongoose.model("policies",policySchema);
module.exports=policyModel