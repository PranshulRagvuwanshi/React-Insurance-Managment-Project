const express=require('express')
const authMiddleware=require('../middleware/authMiddleware')
const { getPolicyInfoController,updatePolicyController, getPolicyByIdController} = require('../controllers/policyCtrl')
const router=express.Router()

router.post('/getPolicyInfo',authMiddleware,getPolicyInfoController)

router.post('/updatePolicy',authMiddleware,updatePolicyController)

router.post('/getPolicyById',authMiddleware,getPolicyByIdController)

module.exports=router