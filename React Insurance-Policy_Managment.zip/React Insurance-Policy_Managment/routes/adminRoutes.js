const express = require("express");
const {
  getAllUsersController,
  getAllPolicyController,
  changePolicyStatusController,
} = require("../controllers/adminCtrl");
const authMiddleware=require("../middleware/authMiddleware")

const router = express.Router();

router.get("/getAllUsers", authMiddleware, getAllUsersController);


router.get("/getAllPolicy", authMiddleware, getAllPolicyController);


router.post(
  "/changePolicyStatus",
  authMiddleware,
  changePolicyStatusController
);

module.exports = router;