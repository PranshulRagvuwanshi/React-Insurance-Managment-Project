const express = require('express');
const { loginController, registerController,authController,applyPolicyController,getAllNotificationController,deleteAllNotificationController, getAllPolicyyController, applicationController} = require('../controllers/userCtrl.js');
const authMiddleware = require('../middleware/authMiddleware.js');

const router = express.Router();

router.post('/login', loginController);
router.post('/register', registerController);

router.post('/getUserData', authMiddleware, authController);

router.post('/take-policy', authMiddleware, applyPolicyController);

router.post('/get-all-notification', authMiddleware, getAllNotificationController);

router.post('/delete-all-notification',authMiddleware,deleteAllNotificationController)

router.get('/getAllPolicy',authMiddleware,getAllPolicyyController)

router.post('/apply-policy',authMiddleware,applicationController)


module.exports = router;
