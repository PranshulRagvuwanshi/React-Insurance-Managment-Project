const userModel = require('../models/userModels');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const policyModel=require('../models/policyModel')
const applyModel=require('../models/applyModel')

const registerController = async (req, res) => {
    try {
        const existingUser = await userModel.findOne({ email: req.body.email });
        if (existingUser) {
            return res.status(200).send({ message: 'User Already Exist', success: false });
        }
        const password = req.body.password;
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);
        req.body.password = hashedPassword;
        const newUser = new userModel(req.body);
        await newUser.save();
        res.status(201).send({ message: "Register Successfully", success: true });
    } catch (error) {
        console.log(error);
        res.status(500).send({ success: false, message: `Register Controller ${error.message}` });
    }
};

const loginController = async (req, res) => {
    try {
        const user = await userModel.findOne({ email: req.body.email });
        if (!user) {
            return res.status(200).send({ message: 'User not found', success: false });
        }
        const isMatch = await bcrypt.compare(req.body.password, user.password);
        if (!isMatch) {
            return res.status(200).send({ message: 'Invalid Email or Password', success: false });
        }
        const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1d' });
        res.status(200).send({ message: 'Login Success', success: true, token });
    } catch (error) {
        console.log(error);
        res.status(500).send({ message: `Error in login Ctrl ${error.message}` });
    }
};

const authController = async (req, res) => {
    try {
        const user = await userModel.findById({ _id: req.body.userId });
        user.password = undefined;
        if (!user) {
            return res.status(200).send({
                message: 'User not found',
                success: false
            });
        } else {
            res.status(200).send({
                success: true,
                data: user
            });
        }
    } catch (error) {
        console.log(error);
        res.status(500).send({
            message: 'Auth error',
            success: false,
            error: error.message
        });
    }
};

const applyPolicyController= async(req,res)=>{
     try {
        const newPolicy=await policyModel({...req.body,status:'pending'})
        await newPolicy.save()
        const adminUser=await userModel.findOne({isAdmin:true})
        const notification=adminUser.notification
        notification.push({
            type:'apply-policy-request',
            message:`${newPolicy.policyName} ${newPolicy.description}Has Applied for a Policy Account`,
            data:{
                policyId:newPolicy._id,
                name:newPolicy.policyName + "" + newPolicy.description,
                onClickPath:'/admin/policies'
            }
        })
        await userModel.findByIdAndUpdate(adminUser._id, { notification });
        res.status(201).send({
            success:true,
            message:'Policy account applied successfully'
        })
     } catch (error) {
        console.log(error)
        res.status(500).send({
            success:false,
            error,
            message:'Error while applying for policy'
        })
     }
}

const getAllNotificationController = async (req, res) => {
    try {
      const user = await userModel.findOne({ _id: req.body.userId });
      const seenotification = user.seenotification;
      const notification = user.notification;
      seenotification.push(...notification);
      user.notification = [];
      user.seenotification = notification;
      const updatedUser = await user.save();
      res.status(200).send({
        success: true,
        message: "all notification marked as read",
        data: updatedUser,
      });
    } catch (error) {
      console.log(error);
      res.status(500).send({
        message: "Error in notification",
        success: false,
        error,
      });
    }
  };

  const deleteAllNotificationController = async (req, res) => {
    try {
      const user = await userModel.findOne({ _id: req.body.userId });
      user.notification = [];
      user.seenotification = [];
      const updatedUser = await user.save();
      updatedUser.password = undefined;
      res.status(200).send({
        success: true,
        message: "Notifications Deleted successfully",
        data: updatedUser,
      });
    } catch (error) {
      console.log(error);
      res.status(500).send({
        success: false,
        message: "unable to delete all notifications",
        error,
      });
    }
  };

  const getAllPolicyyController=async(req,res)=>{
    try {
        const policy=await policyModel.find({status:'approved'})
        res.status(200).send({
            success:true,
            message:"Policy lists fetched successfully",
            data:policy,
        })
    } catch (error) {
        console.log(error)
        res.status(500).send({
            success:false,
            error,
            message:'Error while fetching Policy'
        })
    }
  }

  const applicationController = async (req, res) => {
    try {
        req.body.status = 'pending';
        const newApplication = new applyModel(req.body);
        await newApplication.save();

        const user = await userModel.findOne({ _id: req.body.policyInfo.userId });

        if (!user) {
            return res.status(404).send({
                success: false,
                message: 'User not found'
            });
        }

        user.notification.push({
            type: 'New-application-request',
            message: `A new Appointment Request from ${req.body.userInfo.name}`,
            onClickPath: '/user/applications'
        });

        await user.save();

        res.status(200).send({
            success: true,
            message: 'Application applied successfully'
        });
    } catch (error) {
        console.log(error);
        res.status(500).send({
            success: false,
            error,
            message: 'Error while applying Policy'
        });
    }
};


module.exports = { 
    loginController, 
    registerController, 
    authController, 
    applyPolicyController,
    getAllNotificationController,
    deleteAllNotificationController,
    getAllPolicyyController,
    applicationController,
 };
