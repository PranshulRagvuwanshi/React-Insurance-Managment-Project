const policyModel = require("../models/policyModel");
const userModel = require("../models/userModels");

const getAllUsersController = async (req, res) => {
  try {
    const users = await userModel.find({});
    res.status(200).send({
      success: true,
      message: "users data list",
      data: users,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "erorr while fetching users",
      error,
    });
  }
};

const getAllPolicyController = async (req, res) => {
  try {
    const policy = await policyModel.find({});
    res.status(200).send({
      success: true,
      message: "Policy Data list",
      data: policy,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "error while getting doctors data",
      error,
    });
  }
};

// doctor account status
const changePolicyStatusController = async (req, res) => {
  try {
    const { policyId, status } = req.body;
    const policy = await policyModel.findByIdAndUpdate(policyId, { status });
    const user = await userModel.findOne({ _id: policy.userId });
    const notification = user.notification;
    notification.push({
      type: "policy-request-updated",
      message: `Your Policy Request Has ${status} `,
      onClickPath: "/notification",
    });
    user.isPolicy = status === "approved" ? true : false;
    await user.save();
    res.status(201).send({
      success: true,
      message: "Policy Status Updated",
      data: policy,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error in Policy Status",
      error,
    });
  }
};

module.exports = {
  getAllPolicyController,
  getAllUsersController,
  changePolicyStatusController,
};