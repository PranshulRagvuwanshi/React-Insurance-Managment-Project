const policyModel=require('../models/policyModel')
const getPolicyInfoController= async(req,res) =>{
   try {
      const policy=await policyModel.findOne({userId:req.body.userId})
      res.status(200).send({
        success:true,
        message:'Policy data fetch success',
        data:policy,
      })
   } catch (error) {
    console.log(error)
    res.status(500).send({
        success:false,
        error,
        message:'Error in fetching Policy Details'
    })
   }
}

const updatePolicyController = async(req,res) =>{
    try {
        const policy=await policyModel.findOneAndUpdate({userId:req.body.userId},
            req.body
            );
            res.status(201).send({
                success:true,
                message:'Policy Updated',
                data:policy,
            })
    } catch (error) {
        console.log(error)
        res.status(500).send({
            success:false,
            message:'Policy update issue',
            error
        })
    }
}

const getPolicyByIdController =async(req,res) =>{
    try {
        const policy=await policyModel.findOne({_id:req.body.policyId})
        res.status(200).send({
            success:true,
            message:"Single Policy info fetched",
            data:policy,
        })
    } catch (error) {
        console.log(error)
        res.status(500).send({
            success:false,
            error,
            message:'Error in single policy info'
        })
    }
}

module.exports={getPolicyInfoController,updatePolicyController,getPolicyByIdController}