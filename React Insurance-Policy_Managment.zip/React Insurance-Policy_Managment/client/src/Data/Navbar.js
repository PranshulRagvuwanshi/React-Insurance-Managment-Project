export const userMenu=[
    {
        name:'HOME',
        path:'/',
        icon:"fa-solid fa-house"
    },
    {
        name:'POLICIES',
        path:'/policy',
        icon:'fa-solid fa-notes-medical'
    },
    {
        name:'TAKE POLICY',
        path:'/take-policy',
        icon:'fa-solid fa-book-medical'
    },
    
    {
        name:'ABOUT',
        path:'/about',
        icon:"fa fa-users"
    },
    {
        name:'FAQ',
        path:'/faq',
        icon:"fa-regular fa-question"
    },
    {
        name:'CONTACT',
        path:'/contact',
        icon:"fa fa-phone"
    }
    
]

//Admin Dashboard
export const adminMenu=[
    {
        name:'HOME',
        path:'/',
        icon:"fa-solid fa-house"
    },
    {
        name:'POLICIES',
        path:'/admin/policies',
        icon:'fa-solid fa-book-medical'
    },
    {
        name:'USERS',
        path:'/admin/users',
        icon:'fa-regular fa-address-card'
    },
    {
        name:'PROFILE',
        path:'/admin/profile',
        icon:'fa-regular fa-address-card'
    },
]