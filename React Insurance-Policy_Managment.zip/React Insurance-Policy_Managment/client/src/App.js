import {BrowserRouter,Routes,Route} from 'react-router-dom'
import HomePage from './pages/HomePage';
import Login from './pages/Login';
import Register from './pages/Register';
import Forgot from './pages/Forgot';
import ProtectedRoute from './components/ProtectedRoute';
import PublicRoute from './components/PublicRoute';
import TakePolicy from './pages/TakePolicy';
import NotificationPage from './pages/NotificationPage';
import Users from './pages/admin/Users';
import Policy from './pages/admin/Policy'
import Profile from './pages/policy/Profile'
import ApplyPage from './pages/ApplyPage';
import About from './pages/About';
import Policyy from './pages/Policy';
import Profilee from './pages/admin/Profile';
import Faq from './pages/Faq';
import ContactUs from './pages/Contact';


function App() {
  return (
 <>
   <BrowserRouter>
   <Routes>
        <Route path='/take-policy' element={
        <ProtectedRoute>
                <TakePolicy/>
        </ProtectedRoute>
        }/>
        <Route path='/admin/users' element={
        <ProtectedRoute>
                <Users/>
        </ProtectedRoute>
        }/>
        <Route path='/admin/policies' element={
        <ProtectedRoute>
                <Policy/>
        </ProtectedRoute>
        }/>
        <Route path='/policy/profile/:id' element={
        <ProtectedRoute>
                <Profile/>
        </ProtectedRoute>
        }/>
        <Route path='/policy/apply-policy/:policyId' element={
        <ProtectedRoute>
                <ApplyPage/>
        </ProtectedRoute>
        }/>
        <Route path='/notification' element={
        <ProtectedRoute>
                <NotificationPage/>
        </ProtectedRoute>
        }/>
        <Route path='/login' element={
        <PublicRoute>
                  <Login/>
        </PublicRoute>
        }/>
        <Route path='/about' element={
            <ProtectedRoute>
                <About/>
            </ProtectedRoute>
        }/>
        <Route path='/policy' element={
            <ProtectedRoute>
                <Policyy/>
            </ProtectedRoute>
        }/>
 <Route path='/admin/profile' element={
            <ProtectedRoute>
                <Profilee/>
            </ProtectedRoute>
        }/>

        <Route path='/register' element={
            <PublicRoute>
                <Register/>
            </PublicRoute>
        }/>
        <Route path='/forgot' element={
 <PublicRoute>
        <Forgot/>
 </PublicRoute>
        }/>
         <Route path='/faq' element={
 <ProtectedRoute>
        <Faq/>
 </ProtectedRoute>
        }/>
         <Route path='/contact' element={
 <ProtectedRoute>
        <ContactUs/>
 </ProtectedRoute>
        }/>
          
        
                <Route path='/' element={
        <ProtectedRoute>
                <HomePage/>
        </ProtectedRoute>
        }/>
   </Routes>
   </BrowserRouter>
 </>
  );
}

export default App;
