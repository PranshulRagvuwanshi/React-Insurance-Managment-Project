import React from 'react'
import'../styles/LayoutStyles.css';
import {useNavigate} from 'react-router-dom'

const PolicyList = ({policy}) => {

    const navigate= useNavigate()
  return (
   <>
   
   <div className="card m-2" onClick={() =>navigate(`/policy/apply-policy/${policy._id}`)}>
    <div className='card-header'>
       Name {policy.policyName}
    </div>
    <div className='card-body' >
        <p>
            <b>Email</b> {policy.email}
        </p>
        <p>
            <b>HelpLine</b> {policy.helpline}
        </p>
        <p>
            <b>Coverage</b> {policy.coverage}
        </p>
        <p>
            <b>Description</b> {policy.description}
        </p>

    </div>
   </div>
   </>
  )
}

export default PolicyList
