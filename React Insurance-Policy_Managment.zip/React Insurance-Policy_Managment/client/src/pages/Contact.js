import React from 'react';
import '../styles/ContactStyles.css';

const Contact = () => {
  // Contact details
  
  const phoneNumber = '+1 (123) 456-7890';
  const emailContact = 'contact@insurancecompany.com';
  const twitterAccount = '@insurance_twitter';
  const instagramAccount = '@insurance_instagram';
  const location = '123 Insurance Street, City, State, ZIP Code';

  return (
    <div className="containerStyle">
      <h2 className="titleStyle"><strong>Contact Us</strong></h2>

      <div className="contactDetails">
        <h3>Contact Information</h3>
        
        <p><strong>Phone:</strong> {phoneNumber}</p>
        <p><strong>Email:</strong> {emailContact}</p>
        <p><strong>Twitter:</strong> {twitterAccount}</p>
        <p><strong>Instagram:</strong> {instagramAccount}</p>
        <p><strong>Location:</strong> {location}</p>
      </div>

      <div className="additionalInfo">
        <p>If you have any questions, concerns, or would like more information about our insurance services, please feel free to reach out to us. We are here to help you!</p>
        <p>Our friendly team is available to assist you during our business hours. Don't hesitate to contact us for personalized support and expert advice.</p>
      </div>

      <div className="contactPrompt">
        <p><strong>Feel free to contact us anytime!</strong></p>
      </div>
    </div>
  );
};

export default Contact;