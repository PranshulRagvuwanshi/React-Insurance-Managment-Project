import React from 'react';
import Layout from './../components/Layout'
import {Form,Row,Col,Input, message} from 'antd'
import{useSelector,useDispatch} from 'react-redux'
import{useNavigate} from 'react-router-dom'
import {showLoading,hideLoading} from '../redux/features/alertSlice'
import axios from 'axios'

const TakePolicy = () => {
    const {user} =useSelector(state=>state.user)
     
   const dispatch=useDispatch()
   const navigate=useNavigate()

  const handleFinish=async(values)=>{
    try {
        dispatch(showLoading())
        const res=await axios.post('/api/v1/user/take-policy',{...values,userId:user._id},{
            headers:{
                Authorization:`Bearer ${localStorage.getItem('token')}`
            }
        })
        dispatch(hideLoading())
        if(res.data.success){
            message.success(res.data.message)
            navigate('/')
        }else{
            message.error(res.data.success)
        }
    } catch (error) {
        dispatch(hideLoading())
        console.log(error)
        message.error('Something went wrong')
    }
  }

  return (
   <Layout>
    <h1 className='text-center'>Apply Policy</h1>
    <Form layout='vertical' onFinish={handleFinish} className='m-3'>
    <h4 className='text-light'>Policy Details:</h4>
        <Row gutter={20}> 
            <Col xs={24} md={24} lg={8}>
                <Form.Item 
                label='Policy Name' 
                name='policyName' 
                required 
                rules={[{required:true}]}>
                    <Input type='text' placeholder='policy name'/>
                </Form.Item>
                </Col>
                <Col xs={24} md={24} lg={8}>
                <Form.Item 
                label='Description' 
                name='description' 
                required 
                rules={[{required:true}]}>
                    <Input type='text' placeholder='description'/>
                </Form.Item>
                </Col>
                <Col xs={24} md={24} lg={8}>
                <Form.Item 
                label='Helpline' 
                name='helpline' 
                required 
                rules={[{required:true}]}>
                    <Input type='text' placeholder='helpline'/>
                </Form.Item>
                </Col>
                <Col xs={24} md={24} lg={8}>
                <Form.Item 
                label='Email' 
                name='email' 
                required 
                rules={[{required:true}]}>
                    <Input type='text' placeholder='email'/>
                </Form.Item>
                </Col>
                <Col xs={24} md={24} lg={8}>
                <Form.Item 
                label='Coverage' 
                name='coverage' 
                required 
                rules={[{required:true}]}>
                    <Input type='text' placeholder='insurance to be covered for'/>
                </Form.Item>
                </Col><Col xs={24} md={24} lg={8}>
                <Form.Item 
                label='Amount' 
                name='feesPerMonth' 
                required 
                rules={[{required:true}]}>
                    <Input type='text' placeholder='tobe paid per month'/>
                </Form.Item>
                </Col>
                <Col xs={24} md={24} lg={8}>
                <Col xs={24} md={24} lg={8}>
                    <button className='btn btn-primary form-btn' type='submit'>
                        Submit
                    </button>
                </Col>
                </Col>
        </Row>
    </Form>
   </Layout>
  )
}

export default TakePolicy
