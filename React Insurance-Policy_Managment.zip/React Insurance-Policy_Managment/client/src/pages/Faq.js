import React, { useState } from 'react';
import '../styles/AboutStyles.css'

const Faq = () => {
  const [formData, setFormData] = useState({
    insuranceType: '',
    insuranceQuestion: '',
    customerQuestion: '',
  });

  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    // Add logic for handling the form submission with formData
    console.log('Form Data:', formData);
    // Reset the form after submission
    setFormData({
      insuranceType: '',
      insuranceQuestion: '',
      customerQuestion: '',
    });
    // Set submitted to true to display the thank you message
    setSubmitted(true);
  };

  return (
    <div className="containerStyle">
      <h2 className="titleStyle"><strong>Ask Questions</strong></h2>

      {submitted ? (
        <div className="thankYouMessage">
          <p><strong>Thank you for submitting your question!</strong></p>
        </div>
      ) : (
        <form className="formStyle" onSubmit={handleSubmit}>
          <label className="labelStyle" htmlFor="insuranceType"><strong>Select Insurance Type</strong></label>
          <select
            className="form-select"
            id="insuranceType"
            name="insuranceType"
            value={formData.insuranceType}
            onChange={handleChange}
            required
          >
            <option value="" disabled>Select Insurance Type</option>
            <option value="life">Life Insurance</option>
            <option value="health">Health Insurance</option>
            <option value="motor">Motor Insurance</option>
            <option value="travel">Travel Insurance</option>
          </select>

          <label className="labelStyle" htmlFor="insuranceQuestion"><strong>Select Question Category</strong></label>
          <select
            className="form-select"
            id="insuranceQuestion"
            name="insuranceQuestion"
            value={formData.insuranceQuestion}
            onChange={handleChange}
            required
          >
            <option value="" disabled>Select Question Category</option>
            <option value="Policy Coverage Questions">Policy Coverage Questions</option>
            <option value="Policy Renewal Questions">Policy Renewal Questions</option>
            <option value="Claims Process Questions">Claims Process Questions</option>
            <option value="Policy Modification Questions">Policy Modification Questions</option>
           <option value="Cancellation Questions">Cancellation Questions</option>
           <option value="Discounts and Savings Questions">Discounts and Savings Questions</option>
            <option value="Renewal and Policy Review">Renewal and Policy Review</option>

           
          </select>

          <label className="labelStyle" htmlFor="customerQuestion"><strong>Your Question</strong></label>
          <textarea
            className="form-control"
            id="customerQuestion"
            name="customerQuestion"
            value={formData.customerQuestion}
            onChange={handleChange}
            rows="4"
            required
          ></textarea>

          <div className="buttonContainer">
            <button type="submit" className="buttonStyle"><strong>Submit Question</strong></button>
          </div>
        </form>
      )}
    </div>
  );
};

export default Faq;
