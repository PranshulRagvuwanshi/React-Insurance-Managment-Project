import React from 'react'
import'../styles/ForgotStyles.css'

export default function Forgot() {
  return (
    
      <div className="forgot">
            <h2>Forgot Password</h2>
            <form className="forgot-form">
                <label htmlFor="username">Username</label>
                <input type="username" placeholder="Username" id="username" name="username" required/>
                <label htmlFor="email id">Email id</label>
                <input type="emailid" placeholder="Emailid" id="emailid" name="emailid" required/>
                <label htmlFor="newpassword">Enter New Password</label>
                <input type="password" placeholder="****" id="newpassword" name="newpassword" />
                <label htmlFor="cnfpassword">Confirm New Password</label>
                <input type="password" placeholder="****" id="cnfpassword" name="cnfpassword" /><br />
                <button type="submit">Submit</button>
            </form>
        </div>
   
  )
}
