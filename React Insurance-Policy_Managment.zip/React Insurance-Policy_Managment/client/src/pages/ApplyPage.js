import React,{useState,useEffect} from 'react'
import Layout from '../components/Layout'
import {useParams} from 'react-router-dom'
import axios from 'axios'
import {useDispatch,useSelector} from 'react-redux'
import {showLoading,hideLoading} from '../redux/features/alertSlice'
import { message } from 'antd'

const ApplyPage = () => {
  
  const {user} = useSelector(state => state.user)
  const params=useParams()
  const[policy,setPolicy]=useState([])
  const dispatch=useDispatch()

  const getUserData = async () => {
    try {
      const res = await axios.post(
        '/api/v1/policy/getPolicyById',
        {policyId:params.policyId},
        {
          headers: {
            Authorization: 'Bearer ' + localStorage.getItem('token'),
          },
        }
      );
      if(res.data.message){
        setPolicy(res.data.data)
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleApplication = async() =>{
    try {
       dispatch(showLoading())
       const res=await axios.post('/api/v1/user/apply-policy',
       {
        policyId:params.policyId,
        userId:user._id,
        policyInfo:policy,
        userInfo:user
      },
      {
       headers:{
        Authorization:`Bearer ${localStorage.getItem('token')}`
       }
      }
      )
      dispatch(hideLoading())
      if(res.data.success){
        message.success(res.data.message)
      }
    } catch (error) {
      dispatch(hideLoading)
      console.log(error)
    }
  }

  useEffect(() => {
    getUserData();
    //eslint-disable-next-line
  }, []);

  return (
    <Layout>
      <h3>Apply</h3>
      <div className='container m-2'>
      {policy && (
        <div>
        <h4>Name:{policy.policyName}</h4>
        <h4>Description:{policy.description}</h4>
        <div>
          <button className='btn btn-primary mt-2'onClick={handleApplication}>
            Apply
          </button>
        </div>
        </div>
      )}
      </div>
    </Layout>
  )
}

export default ApplyPage
