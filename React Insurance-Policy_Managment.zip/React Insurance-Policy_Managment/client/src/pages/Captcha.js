import React, { useState, useEffect } from 'react';

const NumberAddingCaptcha = () => {
  debugger
  const [num1, setNum1] = useState(0);
  const [num2, setNum2] = useState(0);
  const [userAnswer, setUserAnswer] = useState('');
  const [captchaCorrect, setCaptchaCorrect] = useState(false);

  useEffect(() => {
    generateNumbers();
  }, []);

  const generateNumbers = () => {
    const number1 = Math.floor(Math.random() * 10);
    const number2 = Math.floor(Math.random() * 10);
    const userAnswerEmpty = "";
    setNum1(number1);
    setNum2(number2);
    setUserAnswer(userAnswerEmpty);
  };

  const checkAnswer = () => {
    debugger
    const sum = num1 + num2;
    const userSum = parseInt(userAnswer);
    if (userSum === sum) {
      setCaptchaCorrect(true);
      alert("Successfull");
    } else {
      setCaptchaCorrect(false);
      // Optionally, you can regenerate numbers for a new CAPTCHA
      generateNumbers();
    }
  };

  return (
    <div>
      <h2>Number Adding CAPTCHA</h2>
      <p>Please solve the CAPTCHA:</p>
      <p>{num1} + {num2} = ?</p>
      <input
        type="text"
        value={userAnswer}
        onChange={(e) => setUserAnswer(e.target.value)}
      />
      <button onClick={checkAnswer}>Submit</button>
      {captchaCorrect && <p>CAPTCHA solved correctly!</p>}
    </div>
  );
};

export default NumberAddingCaptcha;