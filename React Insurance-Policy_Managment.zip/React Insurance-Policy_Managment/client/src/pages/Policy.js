import React from 'react';

const Card = ({ title, content, image }) => (
  <div style={{ width: '300px', height: '400px', border: '1px solid #ccc', borderRadius: '8px', margin: '10px', overflow: 'hidden' }}>
    <img
      src={image}
      alt={title}
      style={{ width: '100%', height: '200px', borderRadius: '8px 8px 0 0', objectFit: 'cover' }}
    />
    <div style={{ padding: '10px', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
      <div>
        <h2 style={{ margin: '0' }}>{title}</h2>
        <p style={{ margin: '0', overflowY: 'auto', maxHeight: '120px', fontSize: '14px' }}>{content}</p>
      </div>
      {/* You can add more elements here if needed */}
    </div>
  </div>
);

const CPolicy = () => {

  const cards = [
    {
      id: 1,
      title: 'Health Insurance Policy',
      content: `Health insurance is a vital financial
      instrument designed to
      provide individuals and families
      with comprehensive coverage for medical expenses and healthcare
      services.`,
      image: '../Inimg/h1.jpg', 
    },
    {
      id: 2,
      title: 'Travel Insurance Policy',
      content: `Travel insurance is a vital financial protection for individuals domestic or international journeys.
      It is for financial risks associated with unforeseen events and emergencies.`,
      image: '../Inimg/Travel.jpg', // Replace with your image URL
    },
    {
      id: 3,
      title: 'Life Insurance Policy',
      content: `Life insurance is a financial contract that known as the death benefit.
      Serves as a crucial financial planning that give protection and financial security to the insured's loved ones`,
      image: '../Inimg/insure.jpg', // Replace with your image URL
    },
    {
      id: 4,
      title: 'Motor Insurance Policy',
      content: `Motor insurance, commonly known as auto insurance is  a financial safeguard that provides coverage for individuals and their vehicles against various risks and
      liabilities.`,
      image: '../Inimg/Car.webp', // Replace with your image URL
    },
  ];

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
      {cards.map((card) => (
        <Card key={card.id} title={card.title} content={card.content} image={card.image} />
      ))}
    </div>
  );
};

export default CPolicy;
