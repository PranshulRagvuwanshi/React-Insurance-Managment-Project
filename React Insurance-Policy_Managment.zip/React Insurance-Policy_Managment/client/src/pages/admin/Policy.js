import React,{useEffect,useState} from 'react'
import Layout from "../../components/Layout"
import axios from 'axios'
import { Table, message } from 'antd'

const Policy = () => {
  const[policy,setPolicy]=useState([])

  const getPolicy=async()=>{
    try {
       const res = await axios.get('/api/v1/admin/getAllPolicy',{
         headers:{
           Authorization:`Bearer ${localStorage.getItem('token')}`
         }
       })
       if(res.data.success){
         setPolicy(res.data.data);
       }
    } catch (error) {
     console.log(error)
    }
}

const handlePolicyStatus=async(record,status) =>{
  try {
    const res= await axios.post('/api/v1/admin/changePolicyStatus',{policyId:record._id,userId:record.userId,status:status},{
      headers:{
        Authorization:`Bearer ${localStorage.getItem('token')}`
      }
    })
    if(res.data.success){
      message.success(res.data.message)
      window.location.reload()
    }
  } catch (error) {
    message.error('Something went wrong')
  }

}

useEffect(() =>{
  getPolicy()
},[])

const columns =[
  {
    title:'Name',
    dataIndex:'name',
    render:(text,record)=> (
      <span>{record.policyName}{record.description}</span>
    )
  },
  {
     title:'Status',
     dataIndex:'status'
  },
  {
    title:'HelpLine',
    dataIndex:'helpline'
  },
  {
    title:'Actions',
    dataIndex:'actions',
    render:(text,record)=>(
      <div className='d-flex'>
        {record.status==='pending' ? (
        <button className='btn btn-success'onClick={()=>handlePolicyStatus(record,'approved')}>Approve</button>
        ):(
        <button className='btn btn-danger'>Reject</button>)}
      </div>
    )
  }
]

  return (
    <Layout>
    <div>
      <h1 className='text-center m-3'>Policy</h1>
      <Table columns={columns} dataSource={policy}/>
    </div>
    </Layout>
  )
}

export default Policy
