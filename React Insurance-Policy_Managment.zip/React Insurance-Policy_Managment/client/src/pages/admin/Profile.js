import React from 'react';

const Profile = () => {
  return (
   
    <div className='container'>
      <h1>
        ADMIN PROFILE
        INSURANCE POLICY MANAGEMENT
        <img src='https://expertphotography.b-cdn.net/wp-content/uploads/2020/08/profile-photos-4.jpg' height='300'></img>
      </h1>
      <h3>Name:Mikey</h3><br/>
      <h3>Email:admin@gmail.com</h3><br/>
      <h3>Role:Admin</h3>
      
    </div>
   
  )
}

export default Profile
