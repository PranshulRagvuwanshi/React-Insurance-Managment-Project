import React, { useEffect,useState } from 'react';
import axios from 'axios';
import Layout from '../components/Layout';
import { Row } from 'antd';
import PolicyList from '../components/PolicyList';

const HomePage = () => {

  const[policy,setPolicy]=useState([])

  const getUserData = async () => {
    try {
      const res = await axios.get(
        '/api/v1/user/getAllPolicy',
        {
          headers: {
            Authorization: 'Bearer ' + localStorage.getItem('token'),
          },
        }
      );
      if(res.data.message){
        setPolicy(res.data.data)
      }
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getUserData();
  }, []);

  return (
    <Layout>
      <h1 className='text-center' >Home Page</h1>
      
      <Row>
        {policy && policy.map(policy=>(
          <PolicyList policy={policy}/>
        ))}
      </Row>
    </Layout>
  );
};

export default HomePage;
