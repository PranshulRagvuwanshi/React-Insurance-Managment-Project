import React from 'react';
 
import '../styles/AboutStyles.css'; // Import your CSS file

const About = () => {
    return (
        <div class="jumbotron">
        <div className="container my-5">
            <h2 className="text-center mb-4"><strong>About Us</strong></h2>
            <p>Welcome to our insurance services! We are dedicated to providing comprehensive coverage tailored to your needs. Below are details about the various insurance types we offer:</p>

            <div className="policy-card">
                <h3>Life Insurance</h3>
                <p>Life insurance provides financial protection to your loved ones in the event of your passing. Our policies offer competitive rates and various coverage options to meet your specific requirements.</p>
                <h4>Policy Details:</h4>
                <ul>
                    <li>Death Benefit</li>
                    <li>Cash Value Accumulation</li>
                    <li>Policy Loans</li>
                </ul>
            </div>

            <div className="policy-card">
                <h3>Health Insurance</h3>
                <p>Our health insurance plans are designed to ensure you receive quality medical care without the financial burden. We offer a range of health coverage options, including individual and family plans.</p>
                <h4>Policy Details:</h4>
                <ul>
                    <li>Hospitalization Coverage</li>
                    <li>Outpatient Services</li>
                    <li>Prescription Drug Coverage</li>
                </ul>
            </div>

            <div className="policy-card">
                <h3>Motor Insurance</h3>
                <p>Protect your vehicle with our motor insurance policies. We provide coverage for damages, accidents, and theft, offering you peace of mind on the road.</p>
                <h4>Policy Details:</h4>
                <ul>
                    <li>Collision Coverage</li>
                    <li>Comprehensive Coverage</li>
                    <li>Liability Coverage</li>
                </ul>
            </div>

            <div className="policy-card">
                <h3>Travel Insurance</h3>
                <p>Travel with confidence using our travel insurance. Our policies cover unexpected events during your journey, including trip cancellations, medical emergencies, and more.</p>
                <h4>Policy Details:</h4>
                <ul>
                    <li>Trip Cancellation Coverage</li>
                    <li>Emergency Medical Coverage</li>
                    <li>Lost Luggage Coverage</li>
                </ul>
            </div>

            <div className="policy-card">
                <h3>Insurance Fees</h3>
                <p>Our fees vary based on the type and coverage of the insurance policy you choose. We strive to offer competitive and transparent pricing to ensure you get the best value for your investment.</p>
                <h4>Fee Structure:</h4>
                <ul>
                    <li>Monthly Premiums</li>
                    <li>Deductibles</li>
                    <li>Co-payments</li>
                </ul>
            </div>

            <div className="policy-card">
                <h3>Upcoming Schemes</h3>
                <p>Stay tuned for our upcoming insurance schemes designed to provide even more benefits and coverage. We are continuously working to enhance our offerings to meet your evolving needs.</p>
            </div>
        </div>
        </div>
    );
}

export default About;
  
