import React from 'react'
import'../styles/RegisterStyles.css'
import { Form,Input,message } from 'antd'
import {Link,useNavigate } from 'react-router-dom'
import {  useState, useEffect, userAnswerEmpty } from 'react'
import axios from'axios'

const Login = () => {

    const navigate=useNavigate()
        
        const [num1, setNum1] = useState(0);
        const [num2, setNum2] = useState(0);
        const [userAnswer, setUserAnswer] = useState('');
        const [captchaCorrect, setCaptchaCorrect] = useState(false);
      
        useEffect(() => {
          generateNumbers();
        }, []);
      
        const generateNumbers = () => {
          const number1 = Math.floor(Math.random() * 10);
          const number2 = Math.floor(Math.random() * 10);
          setNum1(number1);
          setNum2(number2);
          setUserAnswer(userAnswerEmpty);
        };
      
        const checkAnswer = () => {
            debugger
          const sum = num1 + num2;
          const userSum = parseInt(userAnswer);
          if (userSum === sum) {
            setCaptchaCorrect(true);
            alert("Successfull");
          } else {
            setCaptchaCorrect(false);
            // Optionally, you can regenerate numbers for a new CAPTCHA
            generateNumbers();
          }
        };
        const Submitbutton= async(values) =>{
            debugger
            let adminEmail = document.getElementById("Email").value
            let adminPassword = document.getElementById("Password").value
            values = {email:adminEmail,password:adminPassword};
            try{
                
                 const res=await axios.post('/api/v1/user/login',values)
                 window.location.reload()
                 
                 if(res.data.success){
                    localStorage.setItem("token",res.data.token)
                     message.success('Login Successfully')
                     navigate('/')
                 }else{
                    message.error(res.data.message)
                 }
            }catch(error){
                console.log(error.response.data)
                message.error('Something went wrong')
            }
        }
      
       
      
     

  return (
    <div className='form-container '>
    <Form layout='vertical'  className='register-form'>
         <h3 className='text-center'>LoginForm</h3>
         <Form.Item label="Email" name="email">
             <Input type="text" id="Email" required/>
         </Form.Item>
         <Form.Item label="Password" name="password">
             <Input type="text" id="Password" required/>
         </Form.Item>
         <div>
            <h2>Number Adding CAPTCHA</h2>
            <p>Please solve the CAPTCHA:</p>
            <p>{num1} + {num2} = ?</p>
            <input
              type="text"
              value={userAnswer}
              onChange={(e) => setUserAnswer(e.target.value)} required
            />
            <button onClick={checkAnswer}>Verify</button>
            {captchaCorrect && <p>CAPTCHA solved correctly!</p>}
          </div>
         <Link to="/register" className='m-2'><strong>
             Not a user Register here</strong>
        </Link><br/>
        <Link to="/forgot" className='m-2'><strong>
             Forgot Password</strong>
        </Link><br/>
       
         <button class="center-button" onClick={Submitbutton} type='submit'>Login            
        </button>

    </Form>
 </div>
 
  )
}

export default Login